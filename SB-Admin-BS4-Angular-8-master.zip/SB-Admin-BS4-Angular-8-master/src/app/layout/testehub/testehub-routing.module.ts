import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TesteHubComponent } from './testehub.component';

const routes: Routes = [
    {
        path: '', component: TesteHubComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class TesteHubRoutingModule {
}