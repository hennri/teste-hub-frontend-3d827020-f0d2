import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TesteHubRoutingModule } from './testehub-routing.module';
import { TesteHubComponent } from './testehub.component';
import { PageHeaderModule } from './../../shared';

@NgModule({
    imports: [CommonModule, TesteHubRoutingModule, PageHeaderModule],
    declarations: [TesteHubComponent]
})
export class TesteHubModule {}
