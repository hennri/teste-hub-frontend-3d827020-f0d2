import { TesteHubModule } from './testehub.module'

describe('TesteHubModule', () => {
    let testehubModule: TesteHubModule;

    beforeEach(() => {
        testehubModule = new TesteHubModule();
    });

    it('should create an instance', () =>{
        expect(testehubModule).toBeTruthy();
    });
});