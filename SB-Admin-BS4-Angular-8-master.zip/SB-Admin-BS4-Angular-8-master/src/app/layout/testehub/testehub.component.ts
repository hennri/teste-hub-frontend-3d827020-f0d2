import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';

@Component({
    selector: 'app-testehub',
    templateUrl: './testehub.component.html',
    styleUrls: ['./testehub.component.scss'],
    animations: [routerTransition()]
})
export class TesteHubComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
